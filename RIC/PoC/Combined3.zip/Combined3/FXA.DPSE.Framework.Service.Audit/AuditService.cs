﻿using FXA.DPSE.Framework.Common.DTO;
using FXA.DPSE.Framework.Service.Audit.DataAccess;
using FXA.DPSE.Framework.Service.WCF.DTO.Logging;

namespace FXA.DPSE.Framework.Service.Audit
{
    public class AuditService : IAuditService
    {
        private readonly IAuditLogWriter _auditLogWriter;

        /// <summary>
        /// Initializes a new instance of the <see cref="AuditService"/> class.
        /// </summary>
        /// <param name="auditLogWriter">The audit log writer.</param>
        public AuditService(IAuditLogWriter auditLogWriter)
        {
            _auditLogWriter = auditLogWriter;
        }

        /// <summary>
        /// Processes the specified event information.
        /// </summary>
        /// <param name="eventInfo">The event information.</param>
        /// <returns>Response.</returns>
        public Response Event(AuditEventInfo eventInfo)
        {
            //todo: we need to create a common translation service (?)
            //AuditLog auditLog = new AuditLog()
            //{
            //    ClientAddress = eventInfo.ClientAddress ?? "",
            //    CorrelationId = eventInfo.CorrelationId ?? "",
            //    IncomingMessageId = eventInfo.IncomingMessageId ?? "",
            //    MachineName = eventInfo.MachineName ?? "",
            //    Operation = eventInfo.Operation ?? "",
            //    Platform = eventInfo.Platform ?? "",
            //    Request = eventInfo.Request ?? "",
            //    Response = eventInfo.Response ?? "",
            //    ServerName = eventInfo.ServerName ?? "",
            //    ServiceAccountName = eventInfo.ServiceAccountName ?? "",
            //    ServiceUri = eventInfo.ServiceUri ?? "",
            //    Status = eventInfo.Status ?? "",
            //    Version = eventInfo.Version ?? "",
            //    ServerBeginTimeStampUtc = eventInfo.ServerBeginTimeStampUtc,
            //    ServerEndTimeStampUtc = eventInfo.ServerEndTimeStampUtc
            //};

            //todo: this can throw exception... discuss way to treat the exception logging later
            _auditLogWriter.WriteAuditLog(eventInfo);

            Response response = new Response()
            {
                Code = ResponseStatusCode.DPSE_200,
                Version = eventInfo.Version
            };

            return response;
        }
    }
}
