﻿using System;

namespace FXA.Framework.Scheduler
{
    public interface ISchedulerTask
    {
        Guid Id { get; }
        string Name { get; set; }

        object Process();
    }
}