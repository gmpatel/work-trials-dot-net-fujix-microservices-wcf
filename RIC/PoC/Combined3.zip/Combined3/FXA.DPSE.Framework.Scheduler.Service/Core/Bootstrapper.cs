﻿using System.Reflection;
using Autofac;
using Autofac.Configuration;
using Autofac.Extras.Quartz;
using FXA.DPSE.Framework.Common.Infrastructure.Logging.Core;
using FXA.DPSE.Framework.Common.Logging;
using FXA.DPSE.Framework.Common.Windows.Scheduler.Core;
using FXA.Framework.Scheduler.Host.Configuration;

namespace FXA.Framework.Scheduler.Host.Core
{
    internal static class Bootstrapper
    {
        public static IContainer Container { get; private set; }

        static Bootstrapper()
        {
            ConfigureContainer();
        }

        public static IContainer ConfigureContainer()
        {
            var containerBuilder = new ContainerBuilder();

            containerBuilder.RegisterType<SchedulerService>().As<ISchedulerService>();
            containerBuilder.Register(l => Logger.Instance()).As<ILogger>();

            containerBuilder.RegisterModule(new QuartzAutofacFactoryModule());

            containerBuilder.RegisterModule(new QuartzAutofacJobsModule(Assembly.GetExecutingAssembly()));
            containerBuilder.RegisterModule(new QuartzAutofacJobsModule(typeof(SchedulerJobTemplate).Assembly));

            foreach (var assembly in SchedulerConfig.Instance.Assemblies)
            {
                containerBuilder.RegisterModule(new QuartzAutofacJobsModule(assembly));
            }

            var configurationSettingReader = new ConfigurationSettingsReader();
            containerBuilder.RegisterModule(configurationSettingReader);

            Container = containerBuilder.Build();

            return Container;
        }
    }
}
