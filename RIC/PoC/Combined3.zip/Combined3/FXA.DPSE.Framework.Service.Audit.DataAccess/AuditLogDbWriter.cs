﻿using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using FXA.DPSE.Framework.Service.WCF.DTO.Logging;

namespace FXA.DPSE.Framework.Service.Audit.DataAccess
{
    public class AuditLogDbWriter : IAuditLogWriter
    {
        private const string SpWriteLog = "sp_insert_auditlog";
        private const string DbConnectionString = "dbConnectionString";

        /// <summary>
        /// Writes the audit log to the database
        /// </summary>
        /// <param name="auditLog">The audit log.</param>
        public void WriteAuditLog(AuditEventInfo auditLog)
        {
            string connectionString = Settings.GetSetting(DbConnectionString);
            
            List<SqlParameter> parameters = new List<SqlParameter>()
            {
                new SqlParameter()
                {
                    ParameterName = "@version",
                    SqlDbType = SqlDbType.NVarChar,
                    Value = auditLog.Version
                },
                new SqlParameter()
                {
                    ParameterName = "@correlationId",
                    SqlDbType = SqlDbType.NVarChar,
                    Value = auditLog.CorrelationId
                },
                new SqlParameter()
                {
                    ParameterName = "@incomingMessageId",
                    SqlDbType = SqlDbType.NVarChar,
                    Value = auditLog.IncomingMessageId
                },
                new SqlParameter()
                {
                    ParameterName = "@serviceUri",
                    SqlDbType = SqlDbType.NVarChar,
                    Value = auditLog.ServiceUri
                },
                new SqlParameter()
                {
                    ParameterName = "@operation",
                    SqlDbType = SqlDbType.NVarChar,
                    Value = auditLog.Operation
                },
                new SqlParameter()
                {
                    ParameterName = "@clientAddress",
                    SqlDbType = SqlDbType.NVarChar,
                    Value = auditLog.ClientAddress
                },
                new SqlParameter()
                {
                    ParameterName = "@serverName",
                    SqlDbType = SqlDbType.NVarChar,
                    Value = auditLog.ServerName
                },
                new SqlParameter()
                {
                    ParameterName = "@machineName",
                    SqlDbType = SqlDbType.NVarChar,
                    Value = auditLog.MachineName
                },
                new SqlParameter()
                {
                    ParameterName = "@serverBeginTimeStampUtc",
                    SqlDbType = SqlDbType.DateTime,
                    Value = auditLog.ServerBeginTimeStampUtc
                },
                new SqlParameter()
                {
                    ParameterName = "@serverEndTimeStampUtc",
                    SqlDbType = SqlDbType.DateTime,
                    Value = auditLog.ServerEndTimeStampUtc
                },
                 new SqlParameter()
                {
                    ParameterName = "@request",
                    SqlDbType = SqlDbType.NVarChar,
                    Value = auditLog.Request
                },
                 new SqlParameter()
                {
                    ParameterName = "@response",
                    SqlDbType = SqlDbType.NVarChar,
                    Value = auditLog.Response
                },
                 new SqlParameter()
                {
                    ParameterName = "@status",
                    SqlDbType = SqlDbType.NVarChar,
                    Value = auditLog.Status
                },
                 new SqlParameter()
                {
                    ParameterName = "@platform",
                    SqlDbType = SqlDbType.NVarChar,
                    Value = auditLog.Platform
                },
                 new SqlParameter()
                {
                    ParameterName = "@serviceAccountName",
                    SqlDbType = SqlDbType.NVarChar,
                    Value = auditLog.ServiceAccountName
                }
            };
            using (var sqlConn = new SqlConnection(connectionString))
            {
                using (SqlCommand sqlCommand = new SqlCommand(SpWriteLog, sqlConn))
                {
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    sqlCommand.Parameters.AddRange(parameters.ToArray());
                    sqlConn.Open();
                    sqlCommand.ExecuteNonQuery();
                }
            }
        }
    }
}