﻿using FXA.DPSE.Framework.Service.WCF.DTO.Logging;

namespace FXA.DPSE.Framework.Service.Audit.DataAccess
{
    public interface IAuditLogWriter
    {
        void WriteAuditLog(AuditEventInfo auditLog);
    }
}
