﻿using System;

namespace FXA.DPSE.Common.Service.Audit.DataAccess
{
    public class AuditLog
    {
        public string Version { get; set; }

        /// <summary>
        /// DPSE internal message correlationId.
        /// </summary>
        public string CorrelationId { get; set; }

        /// <summary>
        /// DPSE external message identifier.
        /// </summary>
        public string IncomingMessageId { get; set; }

        public string ServiceUri { get; set; }

        public string Operation { get; set; }

        public string ClientAddress { get; set; }

        public string ServerName { get; set; }

        public string MachineName { get; set; }

        public DateTime? ServerBeginTimeStampUtc { get; set; }

        public DateTime? ServerEndTimeStampUtc { get; set; }

        public string Request { get; set; }

        public string Response { get; set; }

        public string Status { get; set; }

        public string Platform { get; set; }

        public string ServiceAccountName { get; set; }
    }
}
