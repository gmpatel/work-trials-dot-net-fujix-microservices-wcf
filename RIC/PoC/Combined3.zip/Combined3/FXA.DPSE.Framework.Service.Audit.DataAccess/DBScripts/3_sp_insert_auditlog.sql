﻿SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Dario Alvarez
-- Create date: 14/09/2015
-- Description:	Inserts a record in the AuditEvent table
-- =============================================
CREATE PROCEDURE sp_insert_auditlog 
	
	@version nvarchar(50),
	@correlationId nvarchar(50),
	@incomingMessageId nvarchar(50),
	@serviceUri nvarchar(50),
	@operation nvarchar(50),
	@clientAddress nvarchar(50),
	@serverName nvarchar(50),
	@machineName nvarchar(50),
	@serverBeginTimeStampUtc datetime,
	@serverEndTimeStampUtc datetime,
	@request nvarchar(50),
	@response nvarchar(50),
	@status nvarchar(50),
	@platform nvarchar(50),
	@serviceAccountName nvarchar(50)

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	INSERT INTO dbo.AuditEvent
	VALUES (
	@version,
	@correlationId,
	@incomingMessageId,
	@serviceUri,
	@operation,
	@clientAddress,
	@serverName,
	@machineName,
	@serverBeginTimeStampUtc,
	@serverEndTimeStampUtc,
	@request,
	@response,
	@status,
	@platform,
	@serviceAccountName);

END
GO
