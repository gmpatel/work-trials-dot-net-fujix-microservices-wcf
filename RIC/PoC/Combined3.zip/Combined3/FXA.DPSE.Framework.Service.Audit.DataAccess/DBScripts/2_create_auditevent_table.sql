﻿USE [NAB]
GO

/****** Object:  Table [dbo].[AuditEvent]    Script Date: 14/09/2015 5:49:17 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[AuditEvent](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Version] [nvarchar](50) NOT NULL,
	[CorrelationId] [nvarchar](50) NOT NULL,
	[IncomingMessageId] [nvarchar](50) NOT NULL,
	[ServiceUri] [nvarchar](50) NOT NULL,
	[Operation] [nvarchar](50) NOT NULL,
	[ClientAddress] [nvarchar](50) NOT NULL,
	[ServerName] [nvarchar](50) NOT NULL,
	[MachineName] [nvarchar](50) NOT NULL,
	[ServerBeginTimeStampUtc] [datetime] NOT NULL,
	[ServerEndTimeStampUtc] [datetime] NOT NULL,
	[Request] [nvarchar](50) NOT NULL,
	[Response] [nvarchar](50) NOT NULL,
	[Status] [nvarchar](50) NOT NULL,
	[Platform] [nvarchar](50) NOT NULL,
	[ServiceAccountName] [nvarchar](50) NOT NULL,
 CONSTRAINT [PK_AuditEvent] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO


