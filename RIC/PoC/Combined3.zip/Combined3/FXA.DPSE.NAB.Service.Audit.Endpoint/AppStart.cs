﻿using Autofac;
using FXA.DPSE.Framework.Service.Audit;
using FXA.DPSE.Framework.Service.Audit.DataAccess;

namespace FXA.DPSE.NAB.Service.Audit.Endpoint
{
    public class AppStart
    {
        public static IContainer BuildContainer()
        {
            var builder = new ContainerBuilder();

            builder.RegisterType<AuditLogDbWriter>().As<IAuditLogWriter>();
            builder.RegisterType<AuditService>().AsSelf();

            IContainer container = builder.Build();
            
            return container;
        }
    }
}