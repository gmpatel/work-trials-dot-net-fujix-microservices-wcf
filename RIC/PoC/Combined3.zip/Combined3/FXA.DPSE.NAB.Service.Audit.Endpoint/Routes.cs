﻿namespace FXA.DPSE.NAB.Service.Audit.Endpoint
{
    public static class Routes
    {
        public const string AuditService = "audit";
    }
}