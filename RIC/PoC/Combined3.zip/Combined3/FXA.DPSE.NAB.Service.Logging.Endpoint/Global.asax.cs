﻿using System;
using System.ServiceModel.Activation;
using System.Web.Routing;
using Autofac;
using Autofac.Integration.Wcf;
using FXA.DPSE.Framework.Common.WcfAutofacIntegration;
using FXA.DPSE.Framework.Service.Logging;

namespace FXA.DPSE.NAB.Service.Logging.Endpoint
{
    public class Global : System.Web.HttpApplication
    {
        protected void Application_Start(object sender, EventArgs e)
        {
            IContainer container = AppStart.BuildContainer();
            AutofacHostFactory.Container = container;
            
            RouteTable.Routes.Add(
                new ServiceRoute(Routes.HealthService,
                    new RestServiceHostFactory<ILoggingService>(),
                    typeof(LoggingService)));
        }
    }
}