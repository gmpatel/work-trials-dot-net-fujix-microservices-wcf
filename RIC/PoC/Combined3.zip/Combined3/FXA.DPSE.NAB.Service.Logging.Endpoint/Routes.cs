﻿namespace FXA.DPSE.NAB.Service.Logging.Endpoint
{
    public static class Routes
    {
        //todo: locate this in a common project
        public const string HealthService = "api/dpse/logging";
    }
}