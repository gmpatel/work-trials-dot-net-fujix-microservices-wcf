﻿using Autofac;
using FXA.DPSE.Framework.Service.Health;

namespace FXA.DPSE.NAB.Service.Health.Endpoint
{
    public class AppStart
    {
        public static IContainer BuildContainer()
        {
            ContainerBuilder builder = new ContainerBuilder();

            builder.RegisterType<HealthService>().AsSelf();
            
            IContainer container = builder.Build();
            return container;
        }
    }
}