﻿using System.ServiceModel;
using System.ServiceModel.Web;
using FXA.DPSE.Framework.Common.DTO;

namespace FXA.DPSE.Framework.Service.LimitChecking
{
    public interface ILimitCheckingService
    {
        [OperationContract]
        [WebInvoke(Method = "POST",
            RequestFormat = WebMessageFormat.Json,
            ResponseFormat = WebMessageFormat.Json)]
        Response CheckLimit(ChequesRequest chequesRequest);
    }
}