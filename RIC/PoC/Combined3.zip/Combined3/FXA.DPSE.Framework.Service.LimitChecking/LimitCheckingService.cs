﻿using System;
using FXA.DPSE.Framework.Common.Config;
using FXA.DPSE.Framework.Common.DTO;

namespace FXA.DPSE.Framework.Service.LimitChecking
{
    public class LimitCheckingService : ILimitCheckingService
    {
        private const string DefaultLimitChecking = "defaultLimitChecking";

        public Response CheckLimit(ChequesRequest chequesRequest)
        {
            string defaultLimitCheckingString = Settings.GetSetting(DefaultLimitChecking);

            double defaultLimitChecking;

            if (Double.TryParse(defaultLimitCheckingString, out defaultLimitChecking))
            {
                //todo: throw new ProcessingException() ?????? invalid setting, cannot be parse to double 
            }

            double totalAmount = 0.0;

            foreach (Cheque cheque in chequesRequest.Cheques)
            {
                double amount = cheque.ChequeAmount;
                totalAmount += amount;

                if (totalAmount > defaultLimitChecking)
                {
                    return new Response()
                    {
                        Code = ResponseStatusCode.DPSE_401,
                        Message = "The cheques total amount is greater than the default limit checking"
                    };
                }
            }

            return new Response()
            {
                Code = ResponseStatusCode.DPSE_200
            };
        }
    }
}