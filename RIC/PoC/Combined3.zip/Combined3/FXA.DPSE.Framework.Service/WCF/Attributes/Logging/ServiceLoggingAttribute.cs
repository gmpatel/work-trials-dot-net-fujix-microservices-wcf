﻿using FXA.DPSE.Framework.Service.WCF;

namespace FXA.DPSE.Framework.Service.WCF.Attributes.Logging
{
    public class ServiceAuditAttribute : ServiceBehaviorBase
    {
        public ServiceAuditAttribute() : base(new AuditMessageInspector())
        {
        }
    }
}