﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Security.Principal;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;
using FXA.DPSE.Framework.Common.Config;
using FXA.DPSE.Framework.Common.RESTClient;
using FXA.DPSE.Framework.Service.Audit;
using FXA.DPSE.Framework.Service.WCF;
using FXA.DPSE.Framework.Service.WCF.Attributes.Logging;
using FXA.DPSE.Framework.Service.WCF.DTO.Logging;
using Response = FXA.DPSE.Framework.Service.WCF.DTO.Messaging.Response.Response;

namespace FXA.DPSE.Framework.Service.WCF.Attributes.Logging
{
    public class AuditMessageInspector : IDispatchMessageInspector
    {
        private const string AuditServiceUrlKey = "auditServiceUrl";

        /// <summary>
        /// Called after an inbound message has been received but before the message is dispatched to the intended operation.
        /// </summary>
        /// <param name="request">The request message.</param>
        /// <param name="channel">The incoming channel.</param>
        /// <param name="instanceContext">The current service instance.</param>
        /// <returns>The object used to correlate state. 
        /// This object is passed back in the 
        /// <see cref="M:System.ServiceModel.Dispatcher.IDispatchMessageInspector.BeforeSendReply(System.ServiceModel.Channels.Message@,System.Object)" /> 
        /// method.</returns>
        public object AfterReceiveRequest(ref Message request, IClientChannel channel, InstanceContext instanceContext)
        {
            //Verification for the IgnoreAudit attribute
            //all methods that have such attribute are not audited
            string methodName = OperationContext.Current.IncomingMessageProperties["HttpOperationName"] as string;
            OperationDescription desc = OperationContext.Current.GetOperationDescription();

            if (!string.IsNullOrEmpty(methodName))
            {
                MethodInfo method = desc.DeclaringContract.ContractType.GetMethod(methodName);
                List<Attribute> attr = method.GetCustomAttributes(typeof(IgnoreAuditAttribute)).ToList();

                if (attr.Any())
                {
                    return null;
                }
            }

            //start of the current auditing
            MessageBuffer buffer = request.CreateBufferedCopy(Int32.MaxValue);
            request = buffer.CreateMessage();
            string rawRequest = buffer.CreateMessage().ToString();

            WindowsIdentity windowsIdentity = WindowsIdentity.GetCurrent();

            var auditEvent = new AuditEventInfo
            {
                //todo: we still are missing the definition of the Version

                Version =  "NA", //not yet defined
                CorrelationId = Guid.NewGuid().ToString(),
                Operation = OperationContext.Current.GetMethodName(),
                ClientAddress = OperationContext.Current.GetClientAddress(),
                Request = rawRequest,
                ServerName = Dns.GetHostName(),
                ServiceUri = OperationContext.Current.IncomingMessageProperties.Via.OriginalString,
                Platform = Platform.WCF.ToString(),
                ServerBeginTimeStampUtc = DateTime.UtcNow,
                ServerEndTimeStampUtc = DateTime.UtcNow,
                Status = request.IsFault ? EventStatus.Failed.ToString() : EventStatus.Succeed.ToString(),
                MachineName = Environment.MachineName,
                ServiceAccountName = windowsIdentity != null ? windowsIdentity.Name : null,
                //todo: this should come from the request message, we don't have the info yet from NAB

                IncomingMessageId = Guid.NewGuid().ToString()
            };

            string auditServiceUrlValue = Settings.GetSetting(AuditServiceUrlKey);

            HttpResult<Response> resultAudit =
                HttpClientExtensions.PostSyncAsJson<AuditEventInfo, Response>(auditServiceUrlValue, auditEvent);

            //todo: verify resultAudit is ok, if not , log/catch exception
            
            return auditEvent;
        }


        /// <summary>
        /// Called after the operation has returned but before the reply message is sent.
        /// </summary>
        /// <param name="reply">The reply message. This value is null if the operation is one way.</param>
        /// <param name="correlationState">The correlation object returned from the 
        /// <see cref="M:System.ServiceModel.Dispatcher.IDispatchMessageInspector.
        /// AfterReceiveRequest(System.ServiceModel.Channels.Message@,System.ServiceModel.IClientChannel,System.ServiceModel.InstanceContext)" /> 
        /// method.</param>
        public void BeforeSendReply(ref Message reply, object correlationState)
        {
            var auditEvent = correlationState as AuditEventInfo;
            if (auditEvent == null) return;

            MessageBuffer messageBuffer = reply.CreateBufferedCopy(int.MaxValue);
            Message responseMessage = messageBuffer.CreateMessage();
            reply = messageBuffer.CreateMessage();

            auditEvent.Response = responseMessage.ToString();
            auditEvent.Status =
                reply.IsFault ?
                EventStatus.Failed.ToString() : EventStatus.Succeed.ToString();
            auditEvent.ServerEndTimeStampUtc = DateTime.UtcNow;

            string auditServiceUrlValue = Settings.GetSetting(AuditServiceUrlKey);

            HttpResult<Response> resultAudit =
                HttpClientExtensions.PostSyncAsJson<AuditEventInfo, Response>(auditServiceUrlValue, auditEvent);

            //todo: verify resultAudit is ok, if not , log/catch exception
        }
    }
}