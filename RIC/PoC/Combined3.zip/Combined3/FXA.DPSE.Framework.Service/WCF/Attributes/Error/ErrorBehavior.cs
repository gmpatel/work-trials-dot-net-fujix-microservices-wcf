﻿namespace FXA.DPSE.Framework.Service.WCF.Attributes.Error
{
    public class ErrorBehavior : ErrorBehaviorBase
    {
        public ErrorBehavior() : base(new ErrorHandler())
        {
        }
    }
}