﻿using System;
using System.ServiceModel.Channels;
using System.ServiceModel.Dispatcher;
using FXA.DPSE.Framework.Common.Exception;

namespace FXA.DPSE.Framework.Service.WCF.Attributes.Error
{
    public class ErrorHandler : IErrorHandler
    {
        public bool HandleError(Exception error)
        {
            //todo: here we can log the exception details
            //call whatever other party involved on this

            //we return true to stop exception propagation in the WCF pipeline,
            //this way the system will consider that the exception is treated ok here

            //todo: perhaps build a httpclient wrapper that handles cases where the 
            //processingexception is received and treats the details variable in certain x way

            if (error is ProcessingException)
            {
                //todo: process and send to LoggingService

                return true;
            }

            //any other type of exception is understood as if it was an unhandled exception being thrown
            if (error != null)
            {
               //todo: send to log as a critical error 

                //todo: how do we plan to signal to stop all processing here ???
                return true;
            }
            
            return true;
        }

        public void ProvideFault(Exception error, MessageVersion version, ref Message fault)
        {
            Response response = null;

            if (error is ProcessingException)
            {
                var processingException = error as ProcessingException;

                //process it and send it to log
                response = new Response()
                {
                    Code = ResponseStatusCode.DPSE_501,
                    Message = processingException.Error.ShortDescription
                };
            }

            //any other type of exception is understood as if it was an unhandled exception being thrown
            if (error != null)
            {
                //critical error
                response = new Response()
                {
                    //TODO: verify if this is the proper message to be placed here
                    Code = ResponseStatusCode.DPSE_501,
                    Message = "Critical internal error" 
                };
            }

            fault = Message.CreateMessage(version, "", response);

        }
    }
}