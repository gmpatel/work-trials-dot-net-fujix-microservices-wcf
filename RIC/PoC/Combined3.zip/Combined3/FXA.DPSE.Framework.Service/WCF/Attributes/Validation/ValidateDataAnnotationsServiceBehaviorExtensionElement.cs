﻿using System;
using System.ServiceModel.Configuration;
using FXA.DPSE.Framework.Service.Attributes.Validation;

namespace FXA.DPSE.Framework.Service.WCF.Attributes.Validation
{
    public class ValidateDataAnnotationsServiceBehaviorExtensionElement : BehaviorExtensionElement
    {
        public override Type BehaviorType
        {
            get { return typeof(ValidationBehavior); }
        }

        protected override object CreateBehavior()
        {
            return new ValidationBehavior();
        }
    }
}   