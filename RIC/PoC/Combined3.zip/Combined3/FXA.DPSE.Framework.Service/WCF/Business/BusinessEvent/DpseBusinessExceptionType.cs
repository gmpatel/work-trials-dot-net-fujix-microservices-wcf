﻿namespace FXA.DPSE.Framework.Service.WCF.Business.BusinessEvent
{
    public enum DpseBusinessExceptionType
    {
        Default,
        Validation,
        Operational
    }
}
