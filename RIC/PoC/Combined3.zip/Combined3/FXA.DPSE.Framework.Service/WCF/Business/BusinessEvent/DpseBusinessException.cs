﻿namespace FXA.DPSE.Framework.Service.WCF.Business.BusinessEvent
{
    public class DpseBusinessException
    {
        protected DpseBusinessException() { }

        public DpseBusinessException(DpseBusinessExceptionType type, string message, string stackTrace, string source)
        {
            ExceptionType = type;
            Message = message;
            StackTrace = stackTrace;
            Source = source;
        }

        public DpseBusinessExceptionType ExceptionType { get; set; }

        public string StackTrace { get; set; }
        public string Source { get; set; }
        public string Message { get; set; }

        //Detail description around the context of the error which assist for troubleshooting.
        public string OperationalMessage { get; set; }
    }
}

