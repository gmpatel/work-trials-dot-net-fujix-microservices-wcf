﻿namespace FXA.DPSE.Framework.Service.WCF.Business.BusinessEvent
{
    public enum DpseBusinessWarningType
    {
        Default,
        Validation,
        Operational
    }
}
