namespace FXA.DPSE.Framework.Service.WCF.Business.BusinessEvent
{
    public interface IDpseBusinessEvent
    {
        string Message { get; }
    }
}