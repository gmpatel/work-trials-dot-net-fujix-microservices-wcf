﻿using System;
using System.ServiceModel;
using System.ServiceModel.Description;

namespace FXA.DPSE.Framework.Service.WCF.Host
{
    public class RestServiceHostFactory<TServiceContract> : AutofacWebServiceHostFactory
    {
        protected override ServiceHost CreateServiceHost(Type serviceType, Uri[] baseAddresses)
        {
            ServiceHost host = new ServiceHost(serviceType, baseAddresses);
            host.AddServiceEndpoint(typeof(TServiceContract), new WebHttpBinding(), "").Behaviors.Add(new WebHttpBehavior());

            ServiceMetadataBehavior smb = new ServiceMetadataBehavior();
            smb.HttpGetEnabled = true;
            host.Description.Behaviors.Add(smb);

            return host;
        }
    }
}