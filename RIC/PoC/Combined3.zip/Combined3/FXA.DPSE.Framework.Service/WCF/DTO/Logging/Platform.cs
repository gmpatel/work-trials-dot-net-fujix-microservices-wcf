namespace FXA.DPSE.Framework.Service.Audit
{
    public enum Platform
    {
        WCF,
        Windows
    }
}