﻿namespace FXA.DPSE.Framework.Service.Audit
{
    public enum EventStatus
    {
        Failed,
        Succeed
    }
}