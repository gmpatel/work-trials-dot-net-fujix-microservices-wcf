﻿using System;
using System.Globalization;
using System.Runtime.Serialization;

namespace FXA.DPSE.Framework.Service.WCF.DTO.Logging
{
    [DataContract]
    public class AuditEventInfo
    {
        [DataMember]
        public string Version { get; set; }

        ///// <summary>
        ///// DPSE internal message correlationId.
        ///// </summary>
        [DataMember]
        public string CorrelationId { get; set; }

        ///// <summary>
        ///// DPSE external message identifier.
        ///// </summary>
        [DataMember]
        public string IncomingMessageId { get; set; }

        [DataMember]
        public string ServiceUri { get; set; }

        [DataMember]
        public string Operation { get; set; }

        [DataMember]
        public string ClientAddress { get; set; }

        [DataMember]
        public string ServerName { get; set; }

        [DataMember]
        public string MachineName { get; set; }

        [DataMember(Name = "ServerBeginTimeStampUtc")]
        public string FormattedServerBeginTimeStampUtc { get; set; }

        [DataMember(Name = "ServerEndTimeStampUtc")]
        public string FormattedServerEndTimeStampUtc { get; set; }



        [IgnoreDataMember]
        public DateTime ServerBeginTimeStampUtc
        {
            get { return DateTime.ParseExact(FormattedServerBeginTimeStampUtc, "o", CultureInfo.InvariantCulture); }
            set { FormattedServerBeginTimeStampUtc = value.ToString("o"); }
        }

        [IgnoreDataMember]
        public DateTime ServerEndTimeStampUtc
        {
            get { return DateTime.ParseExact(FormattedServerEndTimeStampUtc, "o", CultureInfo.InvariantCulture); }
            set { FormattedServerEndTimeStampUtc = value.ToString("o"); }
        }


        [DataMember]
        public string Request { get; set; }

        [DataMember]
        public string Response { get; set; }

        [DataMember]
        public string Status { get; set; }

        [DataMember]
        public string Platform { get; set; }

        [DataMember]
        public string ServiceAccountName { get; set; }
    }
}
