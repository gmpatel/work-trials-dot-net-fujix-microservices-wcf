namespace FXA.DPSE.Framework.Service.WCF.DTO.Messaging
{
    public interface IDpseDtoMessage<out T>
    {
        T Message { get; }
    }
}