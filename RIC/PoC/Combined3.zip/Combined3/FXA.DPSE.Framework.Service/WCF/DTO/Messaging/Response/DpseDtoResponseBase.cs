﻿using System.Runtime.Serialization;

namespace FXA.DPSE.Framework.Service.WCF.DTO.Messaging.Response
{
    [DataContract]
    public abstract class DpseDtoResponseBase : IDpseDtoMessage<DpseResponse>
    {
        [DataMember]
        private readonly DpseResponse _responseInstance = new DpseResponse();
        public DpseResponse Message
        {
            get { return _responseInstance; }
        }
    }
}
