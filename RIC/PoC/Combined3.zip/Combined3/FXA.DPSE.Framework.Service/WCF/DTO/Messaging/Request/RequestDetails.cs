﻿namespace FXA.DPSE.Framework.Service.WCF.DTO.Messaging.Request
{
    public enum ChannelType
    {
        MCC,
        SmartATM,
        SmartClient,
        StandAlone,
    }
}
