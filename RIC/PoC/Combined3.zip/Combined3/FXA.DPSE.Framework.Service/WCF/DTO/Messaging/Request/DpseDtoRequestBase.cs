﻿using System.Runtime.Serialization;

namespace FXA.DPSE.Framework.Service.WCF.DTO.Messaging.Request
{
    [DataContract]
    public abstract class DpseDtoRequestBase : IDpseDtoMessage<DpseRequest>
    {
        [DataMember]
        private readonly DpseRequest _responseInstance = new DpseRequest();
        public DpseRequest Message
        {
            get { return _responseInstance; }
        }
    }
}