﻿using System.Runtime.Serialization;

namespace FXA.DPSE.Framework.Service.WCF.DTO.Messaging.Response
{
    [DataContract]
    public sealed class DpseDtoResponse : IDpseDtoMessage<DpseResponse>
    {
        public DpseDtoResponse()
        {
            _responseInstance = new DpseResponse();
        }

        [DataMember]
        private readonly DpseResponse _responseInstance;

        public DpseResponse Message
        {
            get { return _responseInstance; }
        }
    }
}
