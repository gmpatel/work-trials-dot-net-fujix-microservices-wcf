using System;

namespace FXA.DPSE.Framework.Service.WCF.DTO.Messaging.Request
{
    public class DpseRequest
    {
        public string Version { get; set; }
        public string RequestIdentifier { get; set; }
        public DateTime RequestDateTime { get; set; }
        public ChannelType ChannelType { get; set; }

        public ClientSession ClientSession { get; set; }
    }

    public class ClientSession
    {
        public string SessionId { get; set; }
        public string UserId1 { get; set; }
        public string UserId2 { get; set; }
        public string DeviceId { get; set; }
        public string IpAdderssV4 { get; set; }
        public string IpAdderssV6 { get; set; }
        public string ClientName { get; set; }
        public string ClientVersion { get; set; }
        public string Os { get; set; }
        public string OsVersion { get; set; }
        public string CapturedDevice { get; set; }
    }
}