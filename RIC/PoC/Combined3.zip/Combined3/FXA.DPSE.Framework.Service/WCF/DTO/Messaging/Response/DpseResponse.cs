﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace FXA.DPSE.Framework.Service.WCF.DTO.Messaging.Response
{
    [DataContract]
    public class DpseResponse
    {
        [DataMember]
        public string Code { get; set; }

        [DataMember]
        public string Message { get; set; }

        [DataMember]
        public string IncomingMessageIdentifier { get; set; }

        [DataMember]
        public List<DpseServiceProcessingEvent> Warnings { get; set; }

        [DataMember]
        public DpseServiceProcessingEvent Error { get; set; }
    }

    public class DpseServiceProcessingEvent
    {
        public long EventIdentifier { get; set; }
        public string Description { get; set; }
    }
}