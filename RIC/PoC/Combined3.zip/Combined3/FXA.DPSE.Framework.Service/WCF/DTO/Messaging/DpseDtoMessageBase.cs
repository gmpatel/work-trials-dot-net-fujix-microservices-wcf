using System.Runtime.Serialization;

namespace FXA.DPSE.Framework.Service.WCF.DTO.Messaging
{
    [DataContract]
    public abstract class DpseDtoMessageBase<T> : IDpseDtoMessage<T> where T : new()
    {
        [DataMember]
        private readonly T _responseInstance = new T();
        public T Message
        {
            get { return _responseInstance; }
        }
    }
}