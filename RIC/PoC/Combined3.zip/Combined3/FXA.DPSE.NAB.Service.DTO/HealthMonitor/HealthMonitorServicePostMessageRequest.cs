﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace FXA.DPSE.Framework.Common.Model.HealthMonitorService
{
    [DataContract]
    public class HealthMonitorServicePostMessageRequest
    {
        [DataMember]
        public Guid Id { get; set; }

        [DataMember]
        public string Message { get; set; }
    }
}