﻿using System;

namespace FXA.DPSE.NAB.Service.DTO.DipsTransport
{
    [DataContract]
    public class DipsTransportServicePostMessageRequest
    {
        [DataMember]
        public Guid Id { get; set; }

        [DataMember]
        public string Message { get; set; }
    }
}