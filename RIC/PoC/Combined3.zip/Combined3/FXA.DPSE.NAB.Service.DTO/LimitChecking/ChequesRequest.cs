﻿using System.Runtime.Serialization;

namespace FXA.DPSE.Framework.Service.LimitChecking
{
    [DataContract]
    public class ChequesRequest
    {
        [DataMember(Name="message_version")]
        public string MessageVersion { get; set; }

        [DataMember(Name="request_utc")]
        public string RequestUtc { get; set; }

        [DataMember(Name = "request_guid")]
        public string RequestGuid { get; set; }

        [DataMember(Name = "total_transaction_amount")]
        public float TotalTransactionAmount { get; set; }

        [DataMember(Name = "channel_type")]
        public string ChannelType { get; set; }

        [DataMember(Name = "cheque_count")]
        public string ChequeCount { get; set; }

        [DataMember(Name = "client_session")]
        public ClientSession ClientSession { get; set; }

        [DataMember(Name = "depositing_account_details")]
        public string DepositingAccountDetails { get; set; }

        [DataMember(Name = "cheques")]
        public Cheque[] Cheques { get; set; }
    }

    [DataContract]
    public class ClientSession
    {
        [DataMember(Name = "session_id")]
        public string SessionId { get; set; }
        
        [DataMember(Name = "user_id_1")]
        public string UserId1 { get; set; }
        
        [DataMember(Name = "user_id_2")]
        public string UserId2 { get; set; }

        [DataMember(Name = "device_id")]
        public string DeviceId { get; set; }
        
        [DataMember(Name = "ip_address_v4")]
        public string IpAddressV4 { get; set; }

        [DataMember(Name = "ip_address_v6")]
        public string IpAddressV6 { get; set; }

        [DataMember(Name = "client_name")]
        public string ClientName { get; set; }

        [DataMember(Name = "client_version")]
        public string ClientVersion { get; set; }
        
        [DataMember(Name = "os")]
        public string Os { get; set; }
        
        [DataMember(Name = "os_version")]
        public string OsVersion { get; set; }
        
        [DataMember(Name = "capture_device")]
        public string CaptureDevice { get; set; }

    }

    [DataContract]
    public class DepositingAccountDetails
    {
        [DataMember(Name="account_name")]
        public string AccountName { get; set; }

        [DataMember(Name = "account_number")]
        public string AccountNumber { get; set; }

        [DataMember(Name = "bsb_code")]
        public string BsbCode { get; set; }

        [DataMember(Name = "account_type")]
        public string AccountType { get; set; }
    }

    [DataContract]
    public class Cheque
    {
        [DataMember(Name = "sequence_id")]
        public int SequenceId { get; set; }

        [DataMember(Name = "codeline")]
        public string Codeline { get; set; }

        [DataMember(Name = "cheque_amount")]
        public double ChequeAmount { get; set; }

        [DataMember(Name = "front_image")]
        public string FrontImage { get; set; }

        [DataMember(Name = "rear_image")]
        public string RearImage { get; set; }
    }
}

