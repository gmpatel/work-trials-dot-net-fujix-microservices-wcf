﻿using System;
using System.Data;
using FXA.Framework.Repository.Core.Infrastructure;
using FXA.Framework.Repository.Core.Repositories;

namespace FXA.Framework.Repository.Core.UnitOfWork
{
    public interface IUnitOfWork : IDisposable
    {
        int SaveChanges();
        void Dispose(bool disposing);
        IRepository<TEntity> Repository<TEntity>() where TEntity : class, IObjectState;
        void BeginTransaction(IsolationLevel isolationLevel = IsolationLevel.Unspecified);
        bool Commit();
        void Rollback();
    }
}