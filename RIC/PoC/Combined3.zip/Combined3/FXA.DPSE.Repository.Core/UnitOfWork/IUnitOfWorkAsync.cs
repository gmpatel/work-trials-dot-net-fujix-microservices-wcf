﻿using System.Threading;
using System.Threading.Tasks;
using FXA.Framework.Repository.Core.Infrastructure;
using FXA.Framework.Repository.Core.Repositories;

namespace FXA.Framework.Repository.Core.UnitOfWork
{
    public interface IUnitOfWorkAsync : IUnitOfWork
    {
        Task<int> SaveChangesAsync();
        Task<int> SaveChangesAsync(CancellationToken cancellationToken);
        IRepositoryAsync<TEntity> RepositoryAsync<TEntity>() where TEntity : class, IObjectState;
    }
}