﻿
using System.ComponentModel.DataAnnotations.Schema;

namespace FXA.Framework.Repository.Core.Infrastructure
{
    public interface IObjectState
    {
        [NotMapped]
        ObjectState ObjectState { get; set; }
    }
}