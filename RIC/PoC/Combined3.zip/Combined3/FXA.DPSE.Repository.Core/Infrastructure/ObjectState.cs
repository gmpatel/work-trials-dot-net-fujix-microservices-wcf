﻿namespace FXA.Framework.Repository.Core.Infrastructure
{
    public enum ObjectState
    {
        Unchanged,
        Added,
        Modified,
        Deleted
    }
}