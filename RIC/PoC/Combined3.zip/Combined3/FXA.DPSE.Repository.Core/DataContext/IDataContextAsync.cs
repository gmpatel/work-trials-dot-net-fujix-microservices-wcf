﻿using System.Threading;
using System.Threading.Tasks;

namespace FXA.Framework.Repository.Core.DataContext
{
    public interface IDataContextAsync : IDataContext
    {
        Task<int> SaveChangesAsync(CancellationToken cancellationToken);
        Task<int> SaveChangesAsync();
    }
}