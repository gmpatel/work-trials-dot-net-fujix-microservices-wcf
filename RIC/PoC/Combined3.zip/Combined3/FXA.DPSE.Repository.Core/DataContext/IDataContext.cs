﻿using System;
using FXA.Framework.Repository.Core.Infrastructure;

namespace FXA.Framework.Repository.Core.DataContext
{
    public interface IDataContext : IDisposable
    {
        int SaveChanges();
        void SyncObjectState<TEntity>(TEntity entity) where TEntity : class, IObjectState;
        void SyncObjectsStatePostCommit();
    }
}