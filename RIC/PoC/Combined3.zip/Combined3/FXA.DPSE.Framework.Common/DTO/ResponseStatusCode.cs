﻿namespace FXA.DPSE.Framework.Common.DTO
{
    public class DpseResponseCode
    {
        public const string Success = "DPSE-200";
        public const string InputValidationError = "DPSE-400";
        public const string RequestProcessingError = "DPSE-501";
        public const string DatabaseProcessingError = "DPSE-502";

        public const string TransactionLimitError = "DPSE-600";
    }
}

