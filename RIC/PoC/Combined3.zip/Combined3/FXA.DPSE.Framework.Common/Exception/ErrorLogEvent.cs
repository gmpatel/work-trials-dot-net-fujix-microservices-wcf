﻿namespace FXA.DPSE.Framework.Common.Exception
{
    public class ErrorLogEvent
    {
        public long EventId { get; set; }
        public string ShortDescription { get; set; }
        public string OperationalGuidance { get; set; }
    }
}