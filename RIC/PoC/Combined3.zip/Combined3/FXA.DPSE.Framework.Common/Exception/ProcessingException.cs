﻿using System.Collections.Generic;

namespace FXA.DPSE.Framework.Common.Exception
{
    public class ProcessingException : System.Exception
    {
        public Dictionary<string, string> Details { get; set; }
        public ErrorLogEvent Error { get; set; }

        public ProcessingException()
        {
        }

        public ProcessingException(string message) : base(message)
        {
        }

        public ProcessingException(System.Exception innerException)
            : base(null, innerException)
        {
        }

        public ProcessingException(string message, System.Exception innerException)
            : base(message, innerException)
        {
        }
    }

    public class ProcessingException<TLogEvent> : ProcessingException where TLogEvent : ErrorLogEvent
    {
        public ProcessingException(TLogEvent error)
        {
            this.Error = error;
        }

        public ProcessingException(TLogEvent error, string message) : base(message)
        {
            this.Error = error;
        }

        public ProcessingException(TLogEvent error, System.Exception innerException)
            : base(error.ShortDescription, innerException)
        {
            this.Error = error;
        }

        public ProcessingException(TLogEvent error, string message, System.Exception innerException)
            : base(message, innerException)
        {
            this.Error = error;
        }
    }
}