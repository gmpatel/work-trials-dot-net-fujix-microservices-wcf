﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FXA.DPSE.Service.LimitChecking.Business.Tests.Unit
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
