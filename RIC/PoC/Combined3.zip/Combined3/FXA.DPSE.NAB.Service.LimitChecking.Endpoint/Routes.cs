﻿namespace FXA.DPSE.NAB.Service.LimitChecking.Endpoint
{
    public static class Routes
    {
        //todo: locate this in a common project
        public const string HealthService = "api/dpse/limitchecking";
    }
}