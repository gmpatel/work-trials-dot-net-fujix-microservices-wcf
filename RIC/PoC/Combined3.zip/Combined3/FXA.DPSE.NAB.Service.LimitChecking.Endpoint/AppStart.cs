﻿using Autofac;
using FXA.DPSE.Framework.Service.LimitChecking;

namespace FXA.DPSE.NAB.Service.LimitChecking.Endpoint
{
    public class AppStart
    {
        public static IContainer BuildContainer()
        {
            ContainerBuilder builder = new ContainerBuilder();

            builder.RegisterType<LimitCheckingService>().AsSelf();
            
            IContainer container = builder.Build();
            return container;
        }
    }
}