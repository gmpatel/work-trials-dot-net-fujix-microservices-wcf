﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using FXA.DPSE.Framework.Common;
using FXA.DPSE.Framework.Common.Extensions;
using FXA.DPSE.Framework.Common.Infrastructure.Logging.Core;
using FXA.DPSE.Framework.Common.Model.HealthMonitorService;
using FXA.DPSE.Framework.Common.Properties;
using FXA.DPSE.Framework.Common.RESTClient;
using FXA.DPSE.Framework.Common.Windows.Scheduler.Core;
using FXA.DPSE.MessageDispatcher.HealthMonitor.Configuration;
using Quartz;

namespace FXA.DPSE.MessageDispatcher.HealthMonitor
{
    public class HealthMonitorMessageDispatcherJob : SchedulerJobTemplate
    {
        public HealthMonitorMessageDispatcherJob(ILogger logger) : base(logger)
        {
        }

        public override void ExecuteJob(IJobExecutionContext context)
        {
            var name = context.JobDetail.JobDataMap.Get(JobTemplateDataMapKeys.Name);

            Logger.Info(string.Format("Job : {0} : {1} : {2} : Executing", this.GetType().Name, name, Id));

            foreach (var ep in CustomConfig.Instance.EndPoints)
            {
                var endPoint = ep;
                var request = new HealthMonitorServicePostMessageRequest{ Id = this.Id, Message = "Process Health Check" };

                var thread = new Thread(() =>
                    {
                        Logger.Info(string.Format("Job : {0} : {1} : {2} : Dispatching Request, EndPoint = {3}, Data = {4}", Id, this.GetType().Name, name, endPoint.Url, request.ToJson()));

                        Thread.CurrentThread.IsBackground = true;

                        var response = HttpClientExtensions
                            .PostAsyncAsJson<HealthMonitorServicePostMessageRequest, HealthMonitorServicePostMessageResponse>(endPoint.Url, request)
                            .Result;

                        Logger.Info(string.Format("Job : {0} : {1} : {2} : Response Received, EndPoint = {3}, Data = {4}", Id, this.GetType().Name, name, endPoint.Url, response.ToJson()));
                    }
                );

                thread.Start();
            }

            Logger.Info(string.Format("Job : {0} : {1} : {2} : Completed", this.GetType().Name, name, Id));
        }
    }
}