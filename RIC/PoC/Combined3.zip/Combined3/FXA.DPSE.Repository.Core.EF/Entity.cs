﻿using System.ComponentModel.DataAnnotations.Schema;
using FXA.Framework.Repository.Core.Infrastructure;

namespace FXA.Framework.Repository.Core.EF
{
    public abstract class Entity : IObjectState
    {
        [NotMapped]
        public ObjectState ObjectState { get; set; }
    }
}