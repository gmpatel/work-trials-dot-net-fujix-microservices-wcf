﻿using FXA.DPSE.Framework.Common.Config;
using FXA.DPSE.Framework.Common.DTO;
using FXA.DPSE.Framework.Common.RESTClient;

namespace FXA.DPSE.Framework.Service.Health
{
    public class HealthService : IHealthService
    {
        private const string ServiceEndPoints = "servicesEndpoints";

        /// <summary>
        /// KeepAlive service entry point.
        /// Broadcast a keep alive service call to all respective services in the config/queue.
        /// </summary>
        public void KeepAlive()
        {
            string[] list = Settings.GetSetting(ServiceEndPoints).Split(';');

            //get list of extensions
            foreach (string endpoint in list)
            {
                HttpResult response = HttpClientExtensions.GetSync<Response>(endpoint);
                //todo: process response
            }
        }
    }
}