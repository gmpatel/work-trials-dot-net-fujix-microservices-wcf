﻿using System.ServiceModel;
using System.ServiceModel.Web;

namespace FXA.DPSE.Framework.Service.Health
{
    [ServiceContract]
    public interface IHealthService
    {
        [OperationContract]
        [WebGet(ResponseFormat = WebMessageFormat.Json)]
        void KeepAlive();
    }
}