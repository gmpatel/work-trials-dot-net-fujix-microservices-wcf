﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace FXA.DPSE.Test.DataAnnotationValidator.UnitTest.Model
{
    [DataContract]
    public class SampleServiceResponse
    {
        [Required]
        [DataMember]
        public Guid? Id { get; set; }
    }
}