﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace FXA.DPSE.Test.DataAnnotationValidator.UnitTest.Model
{
    [DataContract]
    public class SampleServiceRequest
    {
        [Required]
        [DataMember]
        public Guid? Id { get; set; }

        [Required]
        [StringLength(500, MinimumLength = 5)]
        [DataMember]
        public string Message { get; set; }
    }
}