﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FXA.DPSE.Test.DataAnnotationValidator.UnitTest.Model;
using System.Threading;
using FXA.DPSE.Framework.Service.Attributes.Error;
using FXA.DPSE.Framework.Service.Attributes.Validation;
using FXA.DPSE.Framework.Service.WCF.Attributes.Error;

namespace FXA.DPSE.Test.DataAnnotationValidator.UnitTest.ServiceLibrary
{
    [ErrorBehavior]
    [ValidationBehavior]
    public class SampleService : ISampleService
    {
        public SampleServiceResponse Post(SampleServiceRequest request)
        {
            Thread.Sleep(3000);
            return new SampleServiceResponse { Id = request.Id };
        }
    }
}