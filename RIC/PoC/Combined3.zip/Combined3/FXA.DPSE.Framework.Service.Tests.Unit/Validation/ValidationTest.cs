﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using FXA.DPSE.Test.DataAnnotationValidator.UnitTest.Model;
using FXA.DPSE.Test.DataAnnotationValidator.UnitTest.ServiceLibrary;
using FXA.DPSE.Test.UnitTestLibrary;
using Xunit;

namespace FXA.DPSE.Test.DataAnnotationValidator.UnitTest
{
    public class ValidationUnitTests : IDisposable
    {
        private const string BaseAddress = "http://localhost:54321";

        private readonly ISampleService _client;
        private readonly ServiceHost _serviceHost;

        public ValidationUnitTests()
        {
            _serviceHost = ServiceHostUtil.CreateServiceHost(new SampleService() as ISampleService, new Uri(BaseAddress), "");
            _client = new ServiceClientTest<ISampleService>(BaseAddress).Proxy;
        }

        public void Dispose()
        {
            _serviceHost.Close();
        }

        [Fact]
        public void Verify_Correct_Request_Returns_Correct_Id_From_Response()
        {
            var id = Guid.NewGuid();
            var request = new SampleServiceRequest { Id = id, Message = "ABCDEFGH" };
            var response = _client.Post(request);

            Assert.Equal(id, response.Id);
        }

        [Fact]
        public void Verify_NULL_Request_Throws_BadRequest_Protocol_Exception()
        {
            Assert.Throws<ProtocolException>(() => _client.Post(null));
        }

        [Fact]
        public void Verify_InCorrect_Request_With_NULL_Id_Throws_BadRequest_Protocol_Exception()
        {
            var request = new SampleServiceRequest { Id = null, Message = "ABCDEFGH" };

            Assert.Throws<ProtocolException>(() => _client.Post(request));
        }

        [Fact]
        public void Verify_InCorrect_Request_With_Message_Shorter_Than_5_Throws_BadRequest_Protocol_Exception()
        {
            var id = Guid.NewGuid();
            var request = new SampleServiceRequest { Id = id, Message = "ABC" };

            Assert.Throws<ProtocolException>(() => _client.Post(request));
        }

        [Fact]
        public void Verify_InCorrect_Request_With_NULL_Id_And_Message_Shorter_Than_5_Throws_BadRequest_Protocol_Exception()
        {
            var request = new SampleServiceRequest { Id = null, Message = "ABC" };

            Assert.Throws<ProtocolException>(() => _client.Post(request));
        }
    }
}