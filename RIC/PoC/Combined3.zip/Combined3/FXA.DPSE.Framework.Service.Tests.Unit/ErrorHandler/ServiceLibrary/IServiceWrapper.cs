﻿using System.ServiceModel;
using System.ServiceModel.Web;

namespace FXA.DPSE.Test.Errorhandler.UnitTest.ServiceLibrary
{
    [ServiceContract]
    public interface IServiceWrapper
    {
        [OperationContract]
        [WebGet(RequestFormat = WebMessageFormat.Json)]
        void ExecuteAction();
    }

    [ServiceContract]
    public interface IServiceWrapper<T>
    {
        [OperationContract]
        [WebGet(RequestFormat = WebMessageFormat.Json)]
        T ExecuteAction();
    }
}
