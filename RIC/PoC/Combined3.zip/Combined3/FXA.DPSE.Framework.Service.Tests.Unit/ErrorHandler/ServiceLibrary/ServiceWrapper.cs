﻿using System;

namespace FXA.DPSE.Test.Errorhandler.UnitTest.ServiceLibrary
{
    public class ServiceWrapper : IServiceWrapper
    {
        private readonly Action _customAction;

        public ServiceWrapper(Action customAction)
        {
            _customAction = customAction;
        }

        public void ExecuteAction()
        {
            _customAction();
        }
    }
}
