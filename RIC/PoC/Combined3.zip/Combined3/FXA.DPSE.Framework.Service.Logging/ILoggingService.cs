﻿using System.ServiceModel;
using System.ServiceModel.Web;
using FXA.DPSE.Framework.Common.DTO;

namespace FXA.DPSE.Framework.Service.Logging
{
    public interface ILoggingService
    {
        [OperationContract]
        [WebInvoke(Method = "POST",
            RequestFormat = WebMessageFormat.Json,
            ResponseFormat = WebMessageFormat.Json)]
        Response Event(string eventInfo);
    }
}