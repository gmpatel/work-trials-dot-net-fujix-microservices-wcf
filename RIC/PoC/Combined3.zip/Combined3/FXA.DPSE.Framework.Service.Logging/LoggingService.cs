﻿using FXA.DPSE.Framework.Common.DTO;

namespace FXA.DPSE.Framework.Service.Logging
{
    public class LoggingService : ILoggingService
    {
        public Response Event(string eventInfo)
        {
            return new Response()
            {
                Message = "",
                Code = ResponseStatusCode.DPSE_200
            };
        }
    }
}