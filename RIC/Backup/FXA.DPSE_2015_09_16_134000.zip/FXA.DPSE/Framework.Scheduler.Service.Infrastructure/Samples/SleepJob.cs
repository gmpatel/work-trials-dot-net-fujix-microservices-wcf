﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using FXA.DPSE.Framework.Scheduler.Service.Infrastructure.Core;
using Quartz;
using FXA.DPSE.Framework.Scheduler.Service.Infrastructure.Properties;

namespace FXA.DPSE.Framework.Scheduler.Service.Infrastructure.Samples
{
    public class SleepJob : IMessageDispatcherJob
    {
        private readonly ILogger _logger;
        
        public Guid Id { get; private set; }
        public IEnumerable<IMessageDispatcherTask> Tasks { get; set; }

        public SleepJob(ILogger logger)
        {
            if (logger == null)
                throw new ArgumentNullException("logger");

            Id = Guid.NewGuid();
        
            _logger = logger;
        }

        public void Execute(IJobExecutionContext context)
        {
            var name = context.JobDetail.JobDataMap.Get(JobDataMapKeys.Name);

            _logger.Info(string.Format("{0} : Job Executing : {1} : {2}", name, Id, this.GetType().Name));

            if (Tasks != null)
            {
                foreach (var task in Tasks)
                {
                    var taskToProcess = task;

                    new Thread(() =>
                    {
                        _logger.Info(string.Format("{0} : {1} : Task Executing : {2} ({3})", name, Id, taskToProcess.Id,
                            taskToProcess.Name));

                        Thread.CurrentThread.IsBackground = true;
                        taskToProcess.Process();

                        _logger.Info(string.Format("{0} : {1} : Task Completed : {2} ({3})", name, Id, taskToProcess.Id,
                            taskToProcess.Name));
                    }).Start();
                }
            }
            else
            {
                var sleepInterval = 5000;
                int.TryParse((context.JobDetail.JobDataMap.ContainsKey(JobDataMapKeys.SleepIntervalInMiliseconds) ? context.JobDetail.JobDataMap.Get(JobDataMapKeys.SleepIntervalInMiliseconds).ToString() : "5000"), out sleepInterval);
                
                _logger.Info(string.Format("{0} : {1} : No Tasks  :  Sleeping For {2} Miliseconds : Started", name, Id, sleepInterval));

                Thread.Sleep(sleepInterval);

                _logger.Info(string.Format("{0} : {1} : No Tasks  :  Sleeping For {2} Miliseconds : Completed", name, Id, sleepInterval));
            }

            _logger.Info(string.Format("{0} : Job Completed : {1} : {2}", name, Id, this.GetType().Name));
        }
    }
}   