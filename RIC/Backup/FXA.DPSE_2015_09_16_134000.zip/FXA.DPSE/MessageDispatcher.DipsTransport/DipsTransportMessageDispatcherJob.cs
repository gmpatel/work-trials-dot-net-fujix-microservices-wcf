﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using FXA.DPSE.Framework.Scheduler.Service.Infrastructure.Core;
using FXA.DPSE.Framework.Scheduler.Service.Infrastructure.Properties;
using FXA.DPSE.MessageDispatcher.DipsTransport.Configuration;
using Quartz;

namespace FXA.DPSE.MessageDispatcher.DipsTransport
{
    public class DipsTransportMessageDispatcherJob : IMessageDispatcherJob
    {
        private readonly ILogger _logger;
        
        public Guid Id { get; private set; }
        
        public DipsTransportMessageDispatcherJob(ILogger logger)
        {
            if (logger == null)
                throw new ArgumentNullException("logger");

            Id = Guid.NewGuid();
        
            _logger = logger;
        }

        public void Execute(IJobExecutionContext context)
        {
            var name = context.JobDetail.JobDataMap.Get(JobDataMapKeys.Name);

            _logger.Info(string.Format("{0} : Job Executing : {1} : {2}", name, Id, this.GetType().Name));

            foreach (var ep in CustomConfig.Instance().EndPoints())
            {
                var endPoint = ep;

                new Thread(() =>
                    {
                        _logger.Info(string.Format("{0} : {1} : Message Dispatching To EndPoint : {2}", name, Id, endPoint.Url));

                        Thread.CurrentThread.IsBackground = true;
                        //Process EndPoint Here

                        _logger.Info(string.Format("{0} : {1} : Message Dispatched To EndPoint : {2}", name, Id, endPoint.Url));
                    }
                ).Start();

                _logger.Info(endPoint.Url);
            }

            _logger.Info(string.Format("{0} : Job Completed : {1} : {2}", name, Id, this.GetType().Name));
        }
    }
}