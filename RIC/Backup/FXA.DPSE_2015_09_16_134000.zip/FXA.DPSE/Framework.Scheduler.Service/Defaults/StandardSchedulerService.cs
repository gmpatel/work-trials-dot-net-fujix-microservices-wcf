﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FXA.DPSE.Framework.Scheduler.Service.Core;
using FXA.DPSE.Framework.Scheduler.Service.Infrastructure.Core;
using Quartz;
using Quartz.Spi;

namespace FXA.DPSE.Framework.Scheduler.Service.Defaults
{
    public class StandardSchedulerService : ITopshelfService
    {
        private readonly IScheduler _scheduler;
        private readonly ILogger _logger;

        public StandardSchedulerService(IScheduler scheduler, IJobFactory jobFactory, ILogger logger)
        {
            if (scheduler == null) 
                throw new ArgumentNullException("scheduler");

            if (jobFactory == null)
                throw new ArgumentNullException("jobFactory");
            
            if (logger == null)
                throw new ArgumentNullException("logger");

            _scheduler = scheduler;
            _logger = logger;

            scheduler.JobFactory = jobFactory;
        }

        public void Start()
        {
            _logger.Info("Starting Service...");

            if (!_scheduler.IsStarted)
            {
                _logger.Info("Starting Scheduler...");
                _scheduler.Start();
            }

            _logger.Info("Service Started...");
        }

        public void Stop()
        {
            _logger.Info("Stopping Service...");

            if (!_scheduler.IsShutdown)
            {
                _logger.Info("Shutting-down Scheduler...");
                
                _scheduler.Shutdown(true);
                _scheduler.Clear();    
            }

            _logger.Info("Service Stopped...");
        }
    }
}   